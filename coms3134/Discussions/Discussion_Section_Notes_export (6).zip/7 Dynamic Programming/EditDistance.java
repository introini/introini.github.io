public class EditDistance {
  public static int editDistance(String s, String t) {
    int[][] table = new int[s.length() + 1][t.length() + 1];

    for (int i = 0; i < s.length() + 1; i++) {
      table[i][0] = i;
    }

    for (int j = 0; j < t.length() + 1; j++) {
      table[0][j] = j;
    }

    for (int i = 1; i < s.length() + 1; i++) {
      for (int j = 1; j < t.length() + 1; j++) {
        int left = table[i - 1][j];
        int down = table[i][j - 1];
        int corner = table[i - 1][j - 1];

        int del = left + 1;
        int ins = down + 1;
        int sub = s.charAt(i - 1) == t.charAt(j - 1) ? corner : corner + 1;

        table[i][j] = Math.min(del, Math.min(ins, sub));
      }
    }

    return table[s.length()][t.length()];
  }

  public static void main(String[] args) {
    System.out.println(editDistance("hello", "world"));
  }
}
