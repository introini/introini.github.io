
public class SuperSoda {
  public static double minimalSodaCost(int[] sodaSizes, double[] costs, int n) {
    double[] minimalCosts = new double[n + 1];
    int smallestSize = sodaSizes[0];
    for (int i = 0; i < smallestSize; i++) {
      minimalCosts[i] = 0;
    }

    for (int i = 1; i < minimalCosts.length; i++) {
      double[] candidates = new double[costs.length];
      for (int j = 0; j < candidates.length; j++) {
        if (i - sodaSizes[j] >= 0) {
          candidates[j] = minimalCosts[i - sodaSizes[j]] + costs[j];
        } else {
          candidates[j] = Double.MAX_VALUE;
        }
      }

      double min = Double.MAX_VALUE;
      for (double candidate : candidates) {
        if (candidate < min) {
          min = candidate;
        }
      }
      minimalCosts[i] = min;
    }

    return minimalCosts[n];
  }

  public static void main(String[] args) {
    int[] sodaSizes = new int[] { 1, 6, 12, 25, 36 };
    double[] costs = new double[] { 0.8, 4, 7.5, 14, 20 };
    System.out.println(minimalSodaCost(sodaSizes, costs, 107));
  }
}
