import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class CoinChange {

  // public static int minimumCoin(int[] combinations, int x) {
  // if (x == 0) {
  // return 0;
  // }
  // if (x == 1) {
  // return 1;
  // }
  // List<Integer> costs = new LinkedList<>();
  //
  // for (int combination : combinations) {
  // if (x - combination >= 0) {
  // costs.add(minimumCoin(combinations, x - combination) + 1);
  // }
  // }
  //
  // return Collections.min(costs).intValue();
  // }

  public static int minimumCoin(int[] combinations, int x) {
    int[] memory = new int[x + 1];
    for (int i = 0; i < memory.length; i++) {
      memory[i] = Integer.MIN_VALUE;
    }
    minimumCoin(combinations, x, memory);
    return memory[x];
  }

  private static void minimumCoin(int[] combinations, int x, int[] memory) {
    if (x == 0) {
      memory[0] = 0;
      return;
    }

    if (x == 1) {
      memory[1] = 1;
      return;
    }

    List<Integer> costs = new LinkedList<Integer>();

    for (int combination : combinations) {
      if (x - combination >= 0) {
        if (memory[x - combination] == Integer.MIN_VALUE) {
          minimumCoin(combinations, x - combination, memory);
        }
        costs.add(memory[x - combination] + 1);
      }
    }

    memory[x] = Collections.min(costs).intValue();
  }

  public static int minimumCoinIterative(int[] combinations, int x) {
    int[] memory = new int[x + 1];
    memory[0] = 0;
    memory[1] = 1;

    for (int i = 1; i < memory.length; i++) {
      int[] candidates = new int[combinations.length];
      for (int j = 0; j < combinations.length; j++) {
        if (i - combinations[j] >= 0) {
          candidates[j] = memory[i - combinations[j]] + 1;
        } else {
          candidates[j] = Integer.MAX_VALUE;
        }
      }

      int min = Integer.MAX_VALUE;
      for (int candidate : candidates) {
        if (candidate < min) {
          min = candidate;
        }
      }
      memory[i] = min;
    }

    return memory[x];
  }

  public static void main(String[] args) {
    int[] combinations = new int[] { 1, 5, 10, 25, 36, 100 };
    System.out.println(minimumCoin(combinations, 120));
    // System.out.println(minimumCoinIterative(combinations, 100));
  }
}
