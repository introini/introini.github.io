public class Fibonacci {
  public static int f(int[] memory, int x) {
    memory[0] = 0;
    memory[1] = 1;
    for (int i = 2; i < memory.length; i++) {
      memory[i] = memory[i - 1] + memory[i - 2];
    }
    return memory[x];
  }

  public static void main(String[] args) {
    int[] memory = new int[30 + 1];
    for (int i = 0; i < memory.length; i++) {
      memory[i] = Integer.MAX_VALUE;
    }
    System.out.println(f(memory, 30));
  }
}
