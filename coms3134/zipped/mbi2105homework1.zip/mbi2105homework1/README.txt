/******************************************************************************\
*                             Michael Introini                                 *
*                                  mbi2105                                     *
*                                                                              *
*                                 COMS 3134                                    *
\******************************************************************************/

Files Submitted: 6

1 - Problem1.java
2 - Problem2.java
3 - Problem3.java
4 - Rectangle.java
5 - Problem215.java
6 - Problem3.txt
7 - README.txt

1 - Problem1.java - Creates an array of Rectangle objects and finds the largest
    rectangle on the basis of its perimeter.
  Compile: javac Problem1.java
  Compile: javac Rectangle.java
  Run: java Problem1

2 - Problem2.java - Builds an array of Rectangle objects, displays the array in
    sorted order, and then searches the array for a pre-defined value using a
    Binary Search algorithm.
  Compile: javac Problem2.java
  Compile: javac Rectangle.java (Not necessary if already compiled with Problem1)
  Run: java Problem2

3 - Problem3.java - Implements the 3 code fragments from written problem 3. Each
    fragment is then run within a for loop that supplies values of n for the
    test.
  Compile: javac Problem3.java
  Run: java Problem3

4 - Rectangle.java - Defines the class Rectangle and provides methods to
    retrieve certain properties of a rectangle, such as the Width and Length.
    Additionally, this provides an override to the compareTo method that is
    used to compare rectangles by perimeter.
  Compile: javac Rectangle.java
  This file DOES NOT need to be run.

5 - Problem215.java - An efficient algorithm to determine if there exists an
    integer i such that Ai = i in an array of integers A1 < A2 < A3 < . . . < AN
    This is the java code that goes with my answer for the written homework 2.15
  Compile: javac Problem215.java
  Run: java Problem215

6 - Problem3.txt - This file contains information for the results of the code
    that was run on Problem3.java

7 - THIS IS THE README.....
