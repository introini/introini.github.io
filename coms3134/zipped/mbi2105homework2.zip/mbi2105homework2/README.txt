/******************************************************************************\
*                             Michael Introini                                 *
*                                  mbi2105                                     *
*                                                                              *
*                                 COMS 3134                                    *
\******************************************************************************/

Files Submitted: 9

1 - written.txt
2 - SymbolBalance.java
3 - MyStack.java (and any other files needed to make this compile)
4 - Test.java
5 - TwoStackQueue.java
6 - MyQueue.java
7 - Program2.java
8 - Program2.txt
9 - README.txt
10 - TwoStacksOneArray.java

2 - SymbolBalance.java - Checks a file taken as an argument for balanced symbols. If the symbols are not properly balance, an error will occur.
  Compile: javac SymbolBalance.java
  Compile: javac MyStack.java
  Run: java SymbolBalance Test.java

3 - MyStack.java - Provides the MyStack Class used in the two Programming Problems. This class allows the implementation os stacks with the given guidlines using a LinkedLists to implement the Push and Pop methods.
  Compile: javac MyStack.java
  Run: Does not run on it's own.

4 - Test.java - Test files for the Symbol Balance program.
  Compile: Not Compiled
  Run: Does not run on it's own.

5 - TwoStackQueue.java Provides methods for the Problem2.java program. Methods provided are enqueue(), dequeue(), size(), isEmpty(), and reverse().
  Compile: javac TwoStackQueue.java
  Compile: javac MyQueue.java
  Compile: javac MyStack.java
  Run: Does not run on it's own.

6 - MyQueue.java Provides the interface implemented in the TwoStackQueue.java class. Defines the methods enqueue(), dequeue(), size(), isEmpty().
  Compile: javac MyQueue.java
  Run: Run: Does not run on it's own.

7 - Program2.java Tests the TwoStackQueue.java class.
  Compile: javac Program2.java
  Compile: javac TwoStackQueue.java
  Compile: javac MyQueue.java
  Compile: javac MyStack.java 
  Run: java Program2
 

